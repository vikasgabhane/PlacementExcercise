package com.excercise1;

public class UpperCase {

	public static void main(String[] args) {
		char ch;
		for(ch='A';ch<='Z';ch++) {
			System.out.print(ch+" ");
		}
	}

}
